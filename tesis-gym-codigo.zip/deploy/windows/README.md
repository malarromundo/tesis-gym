# Estado actual: publicado en Ubuntu

Servidor: 192.168.1.55 (Hyper-V), usuario SSH deltuki.
URL: https://incomexar.sytes.net/rutinatrack
Servicio systemd: rutinatrack, habilitado al arranque.
Código: /opt/rutinatrack; datos: /var/lib/rutinatrack.
Caddy conserva Incomex en 8080 y envía solo /rutinatrack al backend 3132.
Copia previa del proxy: /etc/caddy/Caddyfile.before-rutinatrack-20260929.
Node.js 22.22.1 instalado desde Ubuntu.

Verificado: HTTPS, interfaz, login ADMIN, 44 ejercicios, un usuario inicial,
CORS de las tres apps y respuesta tras reinicio del servicio.
Falta la prueba desde un teléfono con datos móviles y las pruebas nativas.
Las cuentas de la demo de Windows no se transfirieron.

Administración: sudo systemctl status rutinatrack; sudo journalctl -u rutinatrack.
Para respaldar, detener solo rutinatrack, copiar /var/lib/rutinatrack con permisos
protegidos y volver a iniciar el servicio. Mantener encendida la PC y la VM.

Credenciales: archivo local acceso-servidor-ubuntu.txt y en Ubuntu
/var/lib/rutinatrack/admin-inicial.txt. Cambiar la contraseña desde Tu cuenta.
No incluir ninguno de esos archivos ni los datos en distribuciones del código.

## Notas históricas de preparación (anteriores a la publicación)

# Publicación junto a Incomex

Destino elegido: https://incomexar.sytes.net/rutinatrack

El dominio responde con Incomex Argentina en la VM Ubuntu de Hyper-V. No iniciar
otro Caddy de Windows en 80/443 ni reemplazar el servicio de Incomex. La publicación
requiere modificar el Caddy existente en Ubuntu, conservando sus otras rutas.

## Estado comprobado

- El DNS coincide con la IP pública de esta conexión.
- HTTPS del dominio sirve Incomex; todavía no está publicada la ruta RutinaTrack.
- SSH a deltuki@192.168.1.55 agotó el tiempo de espera desde Windows.
- La sesión actual no tiene permisos para administrar Hyper-V ni el firewall.
- El backend preparado en Windows usa datos propios en backend/data-server.
  Las cuentas de demo no pertenecen a esta base. El administrador inicial está
  en backend/data-server/admin-inicial.txt; cambiar su contraseña al ingresar.

## Integración pendiente en Ubuntu

1. Confirmar IP y SSH en la VM: `hostname -I`, `systemctl is-active ssh`.
2. Inspeccionar `/etc/caddy/Caddyfile` y hacer una copia antes de editar.
3. Elegir dónde ejecutar el backend. Preferentemente en la misma VM para evitar
   depender de dos sistemas. Copiar el código sin datos, node_modules ni secretos;
   instalar dependencias con npm ci en raíz, frontend y backend.
4. Compilar con `node scripts/build-server.mjs`.
5. Ejecutar backend/scripts/bootstrap.js desde backend con DATA_DIR persistente,
   PUBLIC_DIR absoluto apuntando a frontend/dist-server, HOST=127.0.0.1,
   PORT=3132 y PUBLIC_ORIGIN=https://incomexar.sytes.net/rutinatrack.
   Configurar el proceso como servicio systemd una vez comprobado el arranque.
6. Integrar rutinatrack.caddy dentro del bloque del dominio. Ese archivo es un
   fragmento, no un reemplazo completo. Respetar las rutas y directivas de Incomex.
7. Validar con `sudo caddy validate --config /etc/caddy/Caddyfile` y, solo si
   resulta correcto, `sudo systemctl reload caddy`.
8. Comprobar que `/rutinatrack/api/health` devuelve application=RutinaTrack,
   que Incomex conserva su login y que RutinaTrack funciona desde datos móviles.

Si el backend queda en Windows: debe escuchar en su IP LAN y el firewall debe
permitir TCP 3132 exclusivamente desde Ubuntu. No publicar 3132 en el router.
start-backend.ps1 sigue limitado a loopback hasta resolver esa topología.

## Clientes

Configurar `https://incomexar.sytes.net/rutinatrack` en el login de las apps nuevas.
La app verifica la identidad del backend antes de guardar la dirección y antes
de enviar credenciales. Un servidor anterior sin la identificación de health
necesita actualizarse. El build web en subruta es independiente del instalador
y del build móvil, que conservan sus rutas locales.

El Caddy de prueba de Windows fue detenido. No obtuvo certificado porque las
validaciones llegaron al Incomex existente. No se abrió el firewall: Windows
rechazó la operación por falta de permisos administrativos.
